from utils import get_hf_credentials

hf_username, hf_token = get_hf_credentials()
print(f"Hugging Face Username: {hf_username}")
print(f"Hugging Face Token: {hf_token}")
