import torch
from PIL import Image
import requests
from unsloth import FastVisionModel

# --- Configuration ---
MODEL_NAME = "mazqoty/gemma-3n-vizWiz-finetuned"
IMAGE_URL = "http://images.cocodataset.org/val2017/000000039769.jpg"  # A sample image of cats
PROMPT = "What is in this image?"

def run_inference(model_name, image_url, prompt):
    """
    Loads a fine-tuned model from Hugging Face, runs inference on an image, and prints the result.
    """
    print(f"Loading model: {model_name}")
    model, processor = FastVisionModel.from_pretrained(
        model_name=model_name,
        load_in_4bit=True,
        dtype=None, # None for auto detection
    )
    print("Model and processor loaded successfully.")

    # Prepare for inference
    FastVisionModel.for_inference(model)

    try:
        print(f"Opening image from URL: {image_url}")
        image = Image.open(requests.get(image_url, stream=True).raw).convert("RGB")
    except Exception as e:
        print(f"Failed to load image from URL: {e}")
        return

    # Format the prompt
    text = f"<|image|>\n{prompt}"

    # Preprocess inputs
    inputs = processor(text=[text], images=[image], return_tensors="pt").to("cuda")

    # Generate output
    print("Running inference...")
    outputs = model.generate(**inputs, max_new_tokens=128, use_cache=True)
    result = processor.batch_decode(outputs, skip_special_tokens=True)[0]

    # Print the result
    print("\n--- Inference Result ---")
    print(result)

if __name__ == "__main__":
    run_inference(MODEL_NAME, IMAGE_URL, PROMPT)
